=== Video Converter ===
Contributors:
Donate link: http://www.speeddownloader.com/convert/donate.php
Tags: youtube, video, download, mp3, converter, convert, Youtube2mp3, youtube downloader, youtube to mp3, youtube mp3, converter, youtube to mp3 converter, download youtube video, vimeo, dailymotion, facebook, instagram, vine, google, vevo, veoh, youku, mobile, tablet, download video, download mp3, embed download, embed, admin, editor, embedding, Smart YouTube PRO, viper’s video tags, YouTube embed, automatic, aute, automate, plugin, widget, seo, google, media, page, video post, url, youtuber, admin, video as mp3, download link, flash, responsive, simple, sidebar, post, links, music, show, movie, content
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 4.7.4
Stable tag: 2.0.2

This Plugin Adds a link under embedded video's that allows to download or convert the video to mp3.

== Description ==

Video Converter

Adds a link under the video embedded that allows to download or convert video to mp3. It supports Youtube and Vimeo at the moment but other portals like, DailyMotion, Facebook, Instagram will be added soon.

Supported Wordpress youtube plugins

Currently these are a number of Youtube Wordpress plugins that we support:

- Default Wordpress behavior without any wordpress plugin (mediaelements.js is not supported yet)
- Smart YouTube PRO
- Viper's Video Quicktags
- YouTube Embed

Supported Sources:

3sat, 8tracks, Archive.org, ARD, Arte.tv, AUEngine, Bandcamp, blip.tv, Break, Brightcove, CollegeHumor, ComedyCentral, CSpan, Dailymotion, DepositFiles, Dotsub, Escapist, Facebook, Flickr, FunnyOrDie, GameSpot, Gametrailers, Generic, HotNewHipHop, Howcast, Hypem, Ina, InfoQ, Instagram, Jukebox, Justin.tv, Keek, Liveleak, Metacafe, Mixcloud, MTV, MySpass, Myvideo, NBA, Photobucket, Plus-Google, RBMA Radio, RBMARadio, Soundcloud, Spiegel, Stanford OC, Statigram, Steam, Teamcoco, TED, TF1, TrailerAddict, Tudou, Tumblr, Tutv, ustream, Veoh, Vevo, Google Video, Vimeo, Vine, Wat.tv, Wimp, WorldStarHipHop, Yahoo, Youtube, Youku, ZDF

If you are using a youtube plugin that's not supported please contact us and we will build support for it.

If you have any problems or suggestion please don't hesitate and contact us on info@speeddownloader.com 

Options include:

- Customize appearance of link with custom css class
- Customize the link text
- Set the position of the link
- Set the plugin to run on only on certain blog-post categories

== Installation ==

1. Upload ‘videoconverter’ folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==


== Screenshots ==
1. Here is how the link is diplayed.
2. The setting page.


== Changelog ==

= 2.0.2 =
- compatibility update
= 2.0.1 =
- bug fixes
= 2.0 =
- option to choose url redirect added
- Changed the default redirect url to http://www.speeddownloader.com
- adding option to add "/?", "/?url=" or "/#url=" at the end of the redirect url
= 1.1.0 =
- Vimeo support added
= 1.0.1 =
- ja_JP language added
= 1.0.1 =
- pt_BR language added
= 1.0 =
- Initial Revision